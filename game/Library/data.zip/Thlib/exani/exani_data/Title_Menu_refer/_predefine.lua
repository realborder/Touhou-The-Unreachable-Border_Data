_predefine={}
_predefine['init']={{startf=1,endf=41},{startf=41,endf=81,repeatc=_infinite}}
_predefine['kill']={{startf=96,endf=108}}
